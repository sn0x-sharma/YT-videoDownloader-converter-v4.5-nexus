## HELLO GUYS AGAIN SN0X HERE 

## ** YT-videoDownloader-converter **
A simple Python script that is able to download YouTube videos or playlists and convert them into MP3.

## Copyright (c) sn0x-sharma 2021 - YT-videoDownloader-converter v4.5 nexus

WARNING: DOWNLOADING COPYRIGHTED MATERIAL IS HIGHLY ILLEGAL!
I DO NOT TAKE ANY RESPONSIBILITY FOR YOUR USAGE OF THIS TOOL!
THIS IS FOR EDUCATIONAL PURPOSES ONLY!
   
     SIGNING OUT!!
             Sn0x-sharma
